const SPOTIFY_API_BASE = 'https://api.spotify.com/v1/me/player/currently-playing';
const ACCESS_TOKEN = 'YOUR_SPOTIFY_ACCESS_TOKEN'; // You should handle token generation using OAuth

export async function getSpotifyCurrentlyPlaying() {
    try {
        const response = await fetch(SPOTIFY_API_BASE, {
            headers: {
                'Authorization': `Bearer ${ACCESS_TOKEN}`,
            },
        });

        if (response.status === 200) {
            const data = await response.json();
            const track_name = data.item.name;
            const artist = data.item.artists[0].name;
            
            return { track_name, artist };
        } else {
            return null;
        }
    } catch (error) {
        console.error('Error fetching currently playing track:', error);
        return null;
    }
}
