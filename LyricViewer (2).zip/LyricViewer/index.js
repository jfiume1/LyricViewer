import { getSpotifyCurrentlyPlaying } from './spotify.js';
import { getLyrics } from './lyrics.js';

let currentLyricIndex = 0;
let lyrics = [];
let syncInterval = null;
let access_token = null;  // Store the access token

// Token refresh function
async function refreshAccessToken() {
    const DeskThing = await window.DeskThing.getInstance();
    const { client_id, client_secret, refresh_token } = DeskThing.getData();  // Get stored tokens

    const authOptions = {
        url: "https://accounts.spotify.com/api/token",
        method: "post",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Authorization: "Basic " + btoa(`${client_id}:${client_secret}`)
        },
        data: new URLSearchParams({
            grant_type: "refresh_token",
            refresh_token: refresh_token
        }).toString()
    };

    try {
        const response = await fetch(authOptions.url, {
            method: authOptions.method,
            headers: authOptions.headers,
            body: authOptions.data
        });
        const data = await response.json();
        access_token = data.access_token;  // Update access token
        DeskThing.saveData({ access_token });  // Save updated token to DeskThing
    } catch (error) {
        DeskThing.sendError("Error refreshing access token: " + error);
    }
}

// Spotify playback control logic (unchanged)
async function handlePlaybackControl(request) {
    let response;
    switch (request) {
        case "next":
            response = await spotify.next();
            break;
        case "previous":
            response = await spotify.previous();
            break;
        case "play":
            response = await spotify.play();
            break;
        case "pause":
            response = await spotify.pause();
            break;
    }
    DeskThing.sendLog(response);
}

// Start function with token refresh handling
async function start() {
    const DeskThing = await window.DeskThing.getInstance();

    async function updateLyrics() {
        try {
            // Ensure token is refreshed
            await refreshAccessToken();

            const songData = await getSpotifyCurrentlyPlaying();
            if (songData) {
                const { track_name, artist, playback_position } = songData;

                // Fetch lyrics based on song title and artist
                lyrics = await getLyrics(track_name, artist);

                if (lyrics && lyrics.length > 0) {
                    syncLyricsWithSpotify(playback_position);
                } else {
                    console.error('No lyrics found!');
                }
            } else {
                console.log("No song playing currently.");
            }
        } catch (error) {
            DeskThing.sendError("Error retrieving song or lyrics: " + error);
        }
    }

    DeskThing.on("start", updateLyrics);
    DeskThing.on("playbackControl", handlePlaybackControl);
    DeskThing.on("stop", () => {
        clearInterval(syncInterval);
    });
}

// Function to display lyrics
function displayLyrics() {
    const lyricsContainer = document.getElementById('lyrics-text');
    lyricsContainer.innerHTML = ""; // Clear previous lyrics

    if (currentLyricIndex < lyrics.length) {
        lyricsContainer.innerHTML = `
            <span class="highlight">${lyrics[currentLyricIndex]}</span><br/>
            ${(lyrics[currentLyricIndex + 1] || "")}
        `;
        currentLyricIndex++;
        syncInterval = setTimeout(displayLyrics, 3000); // Adjust based on song time
    } else {
        currentLyricIndex = 0;
    }
}

// Function to sync lyrics with Spotify playback position
function syncLyricsWithSpotify(playbackPosition) {
    currentLyricIndex = Math.floor(playbackPosition / 3000); // 3 seconds per lyric line
    displayLyrics();
}

start();
